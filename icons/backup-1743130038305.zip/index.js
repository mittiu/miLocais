const discord = require('discord.js');
const { ticketChannelId, adminChannelId, ticketPrefix } = require('./config.json');
const { Client, GatewayIntentBits, PermissionsBitField, ActionRowBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle, ChannelType, Partials, ModalBuilder, TextInputBuilder, TextInputStyle, InteractionType, ActivityType } = require('discord.js');

const fs = require('fs');
const path = require('path');
require('dotenv').config();

// ID do canal de transcrições existente
const TRANSCRICOES_CHANNEL_ID = '1304982317327974411';

const decx = new discord.Client({
    intents: [
        discord.GatewayIntentBits.DirectMessages,
        discord.GatewayIntentBits.Guilds,
        discord.GatewayIntentBits.GuildBans,
        discord.GatewayIntentBits.GuildMessages,
        discord.GatewayIntentBits.MessageContent,
    ],
    partials: [discord.Partials.Channel],
});

const TICKET_CATEGORY_ID = '1304982301742071900'; // Category ID for tickets
const STAFF_ROLE_ID = '1304982278018957465'; // Staff role ID

// Inicialização do bot (código já existente)
decx.on('ready', async () => { 
    console.log(`Logado como ${decx.user.tag}!`);
    const mensagemPrivadaCommand = new discord.SlashCommandBuilder()
    .setName('mensagem_privada')
    .setDescription('Envia uma mensagem privada para o usuário.')
    .addUserOption(option =>
        option.setName('usuario')
            .setDescription('O usuário para quem enviar a mensagem.')
            .setRequired(true))
    .addStringOption(option =>
        option.setName('mensagem')
            .setDescription('A mensagem que deseja enviar.')
            .setRequired(true));

    const pixCommand = new discord.SlashCommandBuilder()
    .setName('pix')
    .setDescription('Exibe as informações de pagamento via Pix.');

    const registroCommand = new discord.SlashCommandBuilder()
    .setName('registro')
    .setDescription('Envia o registro.');

    

await decx.application.commands.create(pixCommand);

await decx.application.commands.create(registroCommand);

await decx.application.commands.create(mensagemPrivadaCommand);

    
    // Define o comando /mudar_nome
    const mudarNomeCommand = new discord.SlashCommandBuilder()
        .setName('mudar_nome')
        .setDescription('Altere o nome do bot no servidor')
        .addStringOption(option => 
            option.setName('nome')
                .setDescription('Novo nome do bot')
                .setRequired(true));

    await decx.application.commands.create(mudarNomeCommand);

    // Define o comando /atividade
    const atividadeCommand = new discord.SlashCommandBuilder()
        .setName('atividade')
        .setDescription('Altere a atividade do bot')
        .addStringOption(option => 
            option.setName('tipo')
                .setDescription('Escolha o tipo de atividade')
                .setRequired(true)
                .addChoices(
                    { name: 'Jogando', value: 'PLAYING' },
                    { name: 'Assistindo', value: 'WATCHING' },
                    { name: 'Ouvindo', value: 'LISTENING' },
                    { name: 'Transmitindo', value: 'STREAMING' } 
                ))
        .addStringOption(option => 
            option.setName('texto')
                .setDescription('Texto da atividade')
                .setRequired(true));

    await decx.application.commands.create(atividadeCommand);

    // Configuração de status cíclico
    const status = [
        '🥇discord.gg/tutushop',
        '💌 Os melhores preços vc encontra aki',
        '🔨 Venha ser um tubarão'
    ];
    let i = 0;
    decx.user.setActivity(status[0]);
    setInterval(() => decx.user.setActivity(`${status[i++ % status.length]}`, {
        type: ActivityType.Playing,
    }), 1000 * 60 * 15);
    decx.user.setStatus('online');
    console.log('😍 ' + decx.user.username + ' started working!');
});

// Escuta o comando /mudar_nome
decx.on('interactionCreate', async interaction => { 

    
    if (!interaction.isCommand()) return;
    if (interaction.commandName === 'mensagem_privada') {
        const user = interaction.options.getUser('usuario');
        const mensagem = interaction.options.getString('mensagem');
    
        if (!user) {
            await interaction.reply({
                content: 'Usuário não encontrado.',
                flags: 64 // Usar flags para mensagens efêmeras (64 equivale a `EPHEMERAL`).
            });
            return;
        }
    
        try {
            await user.send(mensagem);
            await interaction.reply({
                content: `Mensagem enviada para ${user.tag}.`,
                flags: 64
            });
        } catch (error) {
            console.error('Erro ao enviar mensagem privada:', error);
            await interaction.reply({
                content: 'Não foi possível enviar a mensagem. Verifique se o usuário permite mensagens privadas.',
                flags: 64
            });
        }
    }

    const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');

    if (interaction.commandName === 'registro') {
        
// Criando um botão mais bonito
const button = new ButtonBuilder()
.setCustomId('registro_click')
.setLabel('📜 Registrar') // Texto do botão
.setStyle(ButtonStyle.Primary) // Cor verde (pode ser Primary, Danger, etc.)
.setEmoji('✅'); // Emoji no botão

// Criando a linha de ação (necessário para adicionar o botão)
const row = new ActionRowBuilder().addComponents(button);

// Criando um embed estilizado
const embed = new EmbedBuilder()
.setColor(0xFF0000)
.setTitle('<a:d_Borboleta:1305230096944205844> Registro Tutushop <a:d_Borboleta:1305230096944205844>')
.setDescription('Clique no botão abaixo para iniciar seu registro!')
.setFooter({ text: 'Tubarão Shop © Todos os direitos reservados.' })
.setTimestamp();

// Enviando o embed com o botão estilizado
await interaction.reply({ embeds: [embed], components: [row] });
        // await interaction.reply({ content: "<a:d_Borboleta:1305230096944205844> Click para se registrar<a:d_Borboleta:1305230096944205844>", components: [row] });
    }
    decx.on('interactionCreate', async (interaction) => {
        if (!interaction.isButton()) return;
    
        if (interaction.customId === 'registro_click') {
            try {
                const modal = new ModalBuilder()
                    .setCustomId('registro_form')
                    .setTitle('Formulário de Registro');
    
                const nomeInput = new TextInputBuilder()
                    .setCustomId('nome')
                    .setLabel('Seu Nome:')
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true);
    
                const lojaInput = new TextInputBuilder()
                    .setCustomId('loja')
                    .setLabel('Loja e convite de onde trabalha:')
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true);
    
                const modsInput = new TextInputBuilder()
                    .setCustomId('mods')
                    .setLabel('Quantidade e nome dos mods:')
                    .setStyle(TextInputStyle.Paragraph)
                    .setRequired(true);
    
                modal.addComponents(
                    new ActionRowBuilder().addComponents(nomeInput),
                    new ActionRowBuilder().addComponents(lojaInput),
                    new ActionRowBuilder().addComponents(modsInput)
                );
    
                await interaction.showModal(modal);
            } catch (error) {
                console.error('Erro ao exibir modal:', error);
            }
        }
    });
    
    // Listener para processar o formulário do modal
    decx.on('interactionCreate', async (interaction) => {
        if (!interaction.isModalSubmit()) return;
    
        if (interaction.customId === 'registro_form') {
            try {
                const nome = interaction.fields.getTextInputValue('nome');
                const loja = interaction.fields.getTextInputValue('loja');
                const mods = interaction.fields.getTextInputValue('mods');
    
                const embed = new EmbedBuilder()
                    .setColor(0xFF0000)
                    .setTitle('<a:d_Borboleta:1305230096944205844> Registro Tutushop <a:d_Borboleta:1305230096944205844>')
                    .setDescription(
                        `**<:d_Ponto:1305230193668919396> Nome:** ${nome}\n` +
                        `**<:d_Ponto:1305230193668919396> Loja em que trabalha:** ${loja}\n` +
                        `**<:d_Ponto:1305230193668919396> Quantidade de mods e nome dos mods:** ${mods}\n\n` +
                        '** <a:d_SetaVermelha:1305230181795106948> Fica informado pela Tutu Shop, que a revenda/repassa ou vazamento dos mods é altamente proibido. O mod é seu individualmente, não compartilhe.**'
                    )
                    .setFooter({ text: 'Tubarão Shop © Todos os direitos reservados.' })
                    .setTimestamp();
    
                // Enviar o embed no canal onde o usuário clicou no botão
                await interaction.reply({ content: '✅ Registro enviado com sucesso!', ephemeral: true });
                await interaction.channel.send({ embeds: [embed] });
    
                // Enviar para um canal específico
                const canalDeRegistros = interaction.guild.channels.cache.get('1329559353799475251');
                if (canalDeRegistros) {
                    await canalDeRegistros.send({ embeds: [embed] });
                }
            } catch (error) {
                console.error('Erro ao processar interação do modal:', error);
            }
        }
    });
    
    


    if (interaction.commandName === 'pix') {
        const embed = new discord.EmbedBuilder()
            .setColor(0xFF0000)
            .setTitle('Formas de pagamento ⋅ 鮫 ⋅ PIX')
            .setDescription(
                '**<a:d_SetaVermelha:1305230181795106948> Chave Pix: dinomittiu@gmail.com** \n' +
                '**<:d_Ponto:1305230193668919396> João Lucas de Sousa Amaral**\n\n' +
                'Mandar comprovante abaixo:'
            )
            .setImage('https://media.discordapp.net/attachments/1158948553222279290/1369734533800267786/TUTUSHOPQR.png?ex=681cf031&is=681b9eb1&hm=2b467c594e5ec74818773657576ba8f343f60d5c8d445cc4ddb1470ff55bcf84&=&format=webp&quality=lossless&width=1006&height=1006') // Substitua com o link real da imagem
            .setFooter({ text: 'Tubarão Shop © Todos os direitos reservados.' })
            .setTimestamp();
    
        await interaction.reply({ embeds: [embed] });
    }
    
    if (interaction.commandName === 'mudar_nome') {
        const novoNome = interaction.options.getString('nome');
        
        // Altera o nome do bot no servidor atual
        try {
            await interaction.guild.members.cache.get(decx.user.id).setNickname(novoNome);
            await interaction.reply(`Nome do bot alterado para: ${novoNome}`);
        } catch (error) {
            console.error('Erro ao mudar o nome:', error);
            await interaction.reply('Não foi possível alterar o nome do bot. Verifique as permissões.');
        }
    }

    if (interaction.commandName === 'atividade') {
        const tipoAtividade = interaction.options.getString('tipo');
        const textoAtividade = interaction.options.getString('texto');
        
        // Define a atividade do bot
        decx.user.setActivity(textoAtividade, { type: ActivityType[tipoAtividade] });
        
        await interaction.reply(`Atividade alterada para: ${tipoAtividade.toLowerCase()} ${textoAtividade}`);
    }
});

// Gerenciamento de tickets
decx.on('messageCreate', async (msg) => {
    if (msg.author.bot || !msg.member.permissions.has('Administrator') || msg.channel.type === 'dm') return;

    const prefix = ticketPrefix;
    if (!msg.content.startsWith(prefix)) return;
    const ticketChannel = decx.channels.cache.find(channel => channel.id === ticketChannelId);
    msg.delete();

    const row = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
            .setCustomId('ticket')
            .setPlaceholder('Selecione a categoria desejada:')
            .addOptions(
                new StringSelectMenuOptionBuilder().setLabel('Dúvidas / Doubts').setDescription('Suporte geral / General support.').setEmoji('<:9_:1279635441309454438>').setValue('duvidas'),
                new StringSelectMenuOptionBuilder().setLabel('Exclusivos / Exclusives').setDescription('Pedidos exclusivos. / Exclusive orders.').setEmoji('<:11:1279635443666784267>').setValue('exclusivos'),
                new StringSelectMenuOptionBuilder().setLabel('Mods Sims4').setDescription('Mods em geral do sims/gta. / General mods sims/gta.').setEmoji('<:a_TutuFofo:1279262796550377553>').setValue('mods'),
                new StringSelectMenuOptionBuilder().setLabel('Parcerias / Partnerships').setDescription('Se junte á nossa familia de tubarões! / Join our shark family!').setEmoji('<:a_TutuGatinho:1279264604366835712>').setValue('parcerias'),
                new StringSelectMenuOptionBuilder().setLabel('Free / Booster').setDescription('Resgate nosso free ou nosso booster. / Redeem our free or our booster.').setEmoji('<:a_TutuFeliz2:1279264564029952010>').setValue('Free-Booster'),
                new StringSelectMenuOptionBuilder().setLabel('Pronto-Entrega / Ready Delivery').setDescription('Skins prontas para você escolher / Skins ready for you choice').setEmoji('<:a_TutuCoracao4:1279264396509708419>').setValue('pronto-entrega'),
                new StringSelectMenuOptionBuilder().setLabel('English / Espanõl').setDescription('Tickets for other languages / Tickets para otros idiomas').setEmoji('<:a_TutuConfuso2:1279264435323797550>').setValue('English/Espan'),
            )
    ); 

    const embed = new discord.EmbedBuilder()
        .setColor(0xFF001A)
        .setTitle('<a:13:1279652740158718025> Bem-vindo ao Atendimento da Tubarão Shop <a:13:1279652740158718025>')
        .setDescription(
            "\<a:4_:1279634456470229134>  **Antes de abrir um ticket lembre de conferir os termos de compra, para não acontecer futuros incovenientes.**\n\n" +
            "\<:3_:1279634457871257610>  Aqui na **Tubarão Shop**, estamos prontos para ajudar você a mergulhar em uma experiência incrível, abaixo você vai encontrar algumas opções para escolher o serviço que mais combina com o que você precisa.\n\n" +
            " \<:2_:1279634459032817684>  Confira os horários aqui em baixo, para questões de melhor compatibilidade.\n\n" +
            " \<:1_:1279634460232646740>  **Horários de Atendimento:** \n" +
            " Segunda a Sexta: Das 14:00 às 20:00\n" +
            " Sábado e Domingo: Das 17:00 às 21:00\n\n" +
            " \<:1_:1279634460232646740>  **Service Hours:** \n" +
            " Monday to Friday: **2pm to 8pm**\n" +
            " Saturday and Sunday: **5pm to 9pm**,\n"
        )
        .setImage('https://media.discordapp.net/attachments/564102735880912897/1304493459125698641/xxxxxxxx.png?ex=672f97b4&is=672e4634&hm=5ad1c0afa0c1e8d6f5953e6b10bf37e363f862eeab8e65b14a7eefb8b2bdefd3&=&format=webp&quality=lossless&width=1440&height=151')
        .setFooter({ text: "Tubarão shop © Todos os direitos reservados. 2024", iconURL: 'attachment://xxxxxxxx.png' });

    ticketChannel.send({ embeds: [embed], components: [row] });
});

decx.on('interactionCreate', async interaction => {
    if (interaction.isStringSelectMenu() && interaction.customId === 'ticket') {
        const existingTicket = interaction.guild.channels.cache.find(c => c.name === `${interaction.values[0]}-${interaction.user.id}`);
        if (existingTicket) {
            await interaction.reply({ content: `Você já tem um ticket aberto: ${existingTicket}`, ephemeral: true });
            return;
        }

        const category = await interaction.guild.channels.fetch(TICKET_CATEGORY_ID);
        const channel = await interaction.guild.channels.create({
            name: `${interaction.values[0]}-${interaction.user.username}`,
            type: ChannelType.GuildText,
            parent: category.id,
            permissionOverwrites: [
                {
                    id: interaction.guild.id, 
                    deny: [PermissionsBitField.Flags.ViewChannel]
                },
                {
                    id: interaction.user.id, 
                    allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages]
                },
                {
                    id: STAFF_ROLE_ID, 
                    allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages]
                },
                {
                    id: decx.user.id, 
                    allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages]
                }
            ]
        });

        const closeButton = new ButtonBuilder()
            .setCustomId('close_ticket')
            .setLabel('Fechar Ticket')
            .setStyle(ButtonStyle.Danger);

        const addButton = new ButtonBuilder()
            .setCustomId('add_member')
            .setLabel('Adicionar Membro')
            .setStyle(ButtonStyle.Primary);

        const notifyButton = new ButtonBuilder()
            .setCustomId('notify_user')
            .setLabel('Notificar')
            .setStyle(ButtonStyle.Primary);

        const row = new ActionRowBuilder().addComponents(closeButton, addButton, notifyButton);

        const embed = new EmbedBuilder()
            .setColor(0xFF0000)
            .setTitle('<a:13:1279652740158718025> Bem-vindo ao Atendimento da Tubarão Shop! <a:13:1279652740158718025>')
            .setDescription(
                "\<a:5_:1279634455111401568>   Olá, jovem peixinho, e bem-vindo à **Tubarão shop!**\n\n" +
                "\<:3_:1279634457871257610>    Assim que possível, um membro da nossa **Equipe da TuTu** estará à disposição para atender ao seu ticket.\n\n" +
                "\<:3_:1279634457871257610>   Enquanto espera, fale o que está procurando, seja **referências de fotos, prints, tamanho, etc**, assim podemos nos organizar melhor e tornar seu atendimento subaquático ainda mais especial.\n\n" +
                "\<:8_:1279635440072265790>    **A equipe da Tubarão Shop agradece a sua visita!**"
            );

        await channel.send({
            embeds: [embed],
            components: [row]
        });

        await interaction.reply({ content: `Ticket de ${interaction.values[0]} criado: ${channel}`, ephemeral: true });
    }

    if (interaction.isButton()) {
        if (interaction.customId === 'notify_user') {
            const member = await interaction.guild.members.fetch(interaction.user.id);
            const isAdmin = member.roles.cache.has(STAFF_ROLE_ID);
            
            if (!isAdmin) {
                await interaction.reply({ content: "Somente administradores podem usar este botão.", ephemeral: true });
                return;
            }
            
            const username = interaction.channel.name.split('-')[1];
            
            if (!username) {
                await interaction.reply({ content: 'Não foi possível extrair um nome de usuário válido do nome do canal.', ephemeral: true });
                return;
            }
            
            const ticketOwner = interaction.guild.members.cache.find(member => member.user.username === username);
            
            await interaction.reply({ content: 'Notificando o usuário...', ephemeral: true });
            
            try {
                if (ticketOwner) {
                    await ticketOwner.send('Você foi notificado sobre seu ticket!');
                    await interaction.followUp({ content: 'Usuário notificado com sucesso!', ephemeral: true });
                } else {
                    await interaction.followUp({ content: 'Não foi possível encontrar o usuário do ticket.', ephemeral: true });
                }
            } catch (error) {
                await interaction.followUp({ content: 'Erro ao tentar notificar o usuário.', ephemeral: true });
            }
        }

        if (interaction.customId === 'close_ticket') {
            const member = interaction.guild.members.cache.get(interaction.user.id);
            const isAdmin = member.roles.cache.has(STAFF_ROLE_ID);
            
            if (!isAdmin) {
                await interaction.reply({ content: "Somente administradores podem fechar este ticket.", ephemeral: true });
                return;
            }
            
            await interaction.reply({ content: "Fechando o ticket e gerando a transcrição em 5 segundos...", ephemeral: true });
            
            setTimeout(async () => {
                const channel = interaction.channel;
                const messages = await channel.messages.fetch({ limit: 100 });
                let transcript = '';
                
                messages.reverse().forEach(msg => {
                    const time = msg.createdAt.toLocaleString();
                    transcript += `[${time}] ${msg.author.username}: ${msg.content}\n`;
                });
                
                const filePath = path.join('./transcripts', `transcricao-${channel.id}.txt`);
                fs.mkdirSync(path.dirname(filePath), { recursive: true });
                fs.writeFileSync(filePath, transcript);
                
                const transcricoesChannel = await interaction.guild.channels.fetch(TRANSCRICOES_CHANNEL_ID);
                
                const embed = new EmbedBuilder()
                    .setColor(0x00FFFF)
                    .setTitle("Ticket Fechado")
                    .setDescription("<a:d_peixevermelho:1279272610055716884> Muito obrigada pela sua preferência, a Tutu agradece! <a:d_peixevermelho:1279272610055716884>\n\n" +
                      "**Seu ticket acaba de ser fechado, caso surja algum problema você poderá reabri-lo.**")
                    .setFooter({ text: "Tubarão Shop © Todos os direitos reservados. 2024" });

                await transcricoesChannel.send({
                    content: `Transcrição do ticket ${channel.name}`,
                    files: [filePath]
                });

                const ticketOwner = interaction.guild.members.cache.find(member => member.user.username === channel.name.split('-')[1]);

                if (ticketOwner) {
                    await ticketOwner.send({
                        embeds: [embed],
                        files: [filePath]
                    });
                }

                await channel.delete();
            }, 5000);
        }

        if (interaction.customId === 'add_member') {
            const member = interaction.guild.members.cache.get(interaction.user.id);
            const isAdmin = member.roles.cache.has(STAFF_ROLE_ID);

            if (!isAdmin) {
                await interaction.reply({ content: "Somente administradores podem adicionar membros a este ticket.", ephemeral: true });
                return;
            }
            const modal = new ModalBuilder()
                .setCustomId('add_member_modal')
                .setTitle('Adicionar Membro ao Ticket');

            const userInput = new TextInputBuilder()
                .setCustomId('user_id')
                .setLabel("ID do Usuário")
                .setPlaceholder("Insira o ID do usuário que deseja adicionar")
                .setStyle(TextInputStyle.Short);
                const modalRow = new ActionRowBuilder().addComponents(userInput);
                modal.addComponents(modalRow); 
                
                await interaction.showModal(modal);
                    }
                }
                
                if (interaction.type === InteractionType.ModalSubmit && interaction.customId === 'add_member_modal') {
                    const userId = interaction.fields.getTextInputValue('user_id');
                    const member = await interaction.guild.members.fetch(userId).catch(() => null);
                
                    if (!member) {
                        await interaction.reply({ content: "Usuário não encontrado. Verifique o ID inserido.", ephemeral: true });
                        return;
                    }
                
                    await interaction.channel.permissionOverwrites.edit(member, {
                        ViewChannel: true,
                        SendMessages: true
                    });
                
                    await interaction.reply({ content: `${member} foi adicionado ao ticket.`, ephemeral: true });
                }
});   
 







decx.login("MTMyOTE2NDMxMjc3ODExMzA5NQ.GNpPDt.wfrXJkp0bMybTNWx_eJPcHijmOm9U5Y3TW4vjs"); 



// require('dotenv').config();
// const { Client, GatewayIntentBits, SlashCommandBuilder } = require('discord.js');

// const client = new Client({ intents: [GatewayIntentBits.Guilds] });

// client.on('ready', () => {
//     console.log(`Logado como ${client.user.tag}!`);

//     const command = new SlashCommandBuilder()
//         .setName('convidar')
//         .setDescription('Gera um link de convite para adicionar o bot ao servidor');

//     client.application.commands.create(command);
// });

// client.on('interactionCreate', async interaction => {
//     if (!interaction.isCommand()) return;

//     const { commandName } = interaction;

//     if (commandName === 'convidar') {
//         const invite = await interaction.channel.createInvite({ unique: true });
//         await interaction.reply(`Use este link para convidar o bot: ${invite.url}`);
//     }
// });

// client.login(process.env.TOKEN);